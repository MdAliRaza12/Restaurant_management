package com.geekster.weeklyTest.project.RestaurantManagementApplication.Model.Enums;

public enum OrderStatus {
    CREATED, DISPATCH, DELIVERED
}
