package com.geekster.weeklyTest.project.RestaurantManagementApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
