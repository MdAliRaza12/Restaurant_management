package com.geekster.project.RestaurantManagementServiceAPI.Enums;

public enum OrderStatus {
    CREATED,
    DISPATCHED,
    DELIVERED
}

