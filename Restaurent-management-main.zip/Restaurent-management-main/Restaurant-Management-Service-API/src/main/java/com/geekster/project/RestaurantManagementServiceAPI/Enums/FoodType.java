package com.geekster.project.RestaurantManagementServiceAPI.Enums;

public enum FoodType {
    APPETIZER,
    MAIN_COURSE,
    DESSERT,
    BEVERAGE
}
